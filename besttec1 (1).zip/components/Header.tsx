"use client"
import { useState } from "react"
import { Menu, Search, User } from "lucide-react"
import { useLanguage } from "@/contexts/LanguageContext"
import Sidebar from "./Sidebar"
import Link from "next/link"

export default function Header() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { language } = useLanguage()

  return (
    <>
      <header className="w-full bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-14 sm:h-16 lg:h-20 flex items-center justify-between relative">
            {language === "ar" ? (
              <>
                {/* Arabic Layout */}
                <div className="flex items-center">
                  <button
                    onClick={() => setSidebarOpen(true)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Menu className="w-5 h-5 sm:w-6 sm:h-6 lg:w-7 lg:h-7" />
                  </button>
                </div>

                <Link href="/" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                  <h1 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-bold text-black hover:text-gray-700 transition-colors whitespace-nowrap">
                    BestPlatec
                  </h1>
                </Link>

                <div className="flex items-center gap-1 sm:gap-2 lg:gap-3">
                  <Link href="/search">
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Search className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6" />
                    </button>
                  </Link>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <User className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6" />
                  </button>
                </div>
              </>
            ) : (
              <>
                {/* English Layout */}
                <div className="flex items-center">
                  <button
                    onClick={() => setSidebarOpen(true)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Menu className="w-5 h-5 sm:w-6 sm:h-6 lg:w-7 lg:h-7" />
                  </button>
                </div>

                <Link href="/" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                  <h1 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-bold text-black hover:text-gray-700 transition-colors whitespace-nowrap">
                    BestPlatec
                  </h1>
                </Link>

                <div className="flex items-center gap-1 sm:gap-2 lg:gap-3">
                  <Link href="/search">
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Search className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6" />
                    </button>
                  </Link>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <User className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {sidebarOpen && <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />}
    </>
  )
}
