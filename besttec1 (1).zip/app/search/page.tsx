"use client"
import { useState } from "react"
import type React from "react"
import { Search, ArrowRight, ArrowLeft, X } from "lucide-react"
import { useLanguage } from "@/contexts/LanguageContext"
import { useRouter } from "next/navigation"

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const { language } = useLanguage()
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("البحث عن:", searchQuery)
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 sm:mb-8 lg:mb-12">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-gray-600 hover:text-black transition-colors text-sm sm:text-base lg:text-lg"
          >
            {language === "ar" ? (
              <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
            ) : (
              <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
            )}
            <span>{language === "ar" ? "العودة" : "Back"}</span>
          </button>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold">{language === "ar" ? "البحث" : "Search"}</h1>
          <div className="w-16 sm:w-20"></div>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSearch} className="mb-8 sm:mb-12">
          <div className="flex items-center bg-white border-2 border-gray-200 rounded-2xl overflow-hidden hover:border-black transition-colors focus-within:border-black shadow-lg">
            {language === "ar" ? (
              <>
                {/* Arabic Layout */}
                <div className="flex items-center justify-center bg-gray-50 border-r-2 border-gray-200 w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16">
                  <Search className="w-5 h-5 sm:w-6 sm:h-6 text-gray-400" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن المحتوى..."
                  className="flex-1 px-4 sm:px-6 text-base sm:text-lg focus:outline-none text-right h-12 sm:h-14 lg:h-16"
                  dir="rtl"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="flex items-center justify-center hover:bg-gray-100 transition-colors border-l-2 border-gray-200 w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 mr-3"
                  >
                    <X className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
                  </button>
                )}
              </>
            ) : (
              <>
                {/* English Layout */}
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="flex items-center justify-center hover:bg-gray-100 transition-colors border-r-2 border-gray-200 w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 ml-3"
                  >
                    <X className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
                  </button>
                )}
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for content..."
                  className="flex-1 px-4 sm:px-6 text-base sm:text-lg focus:outline-none text-left h-12 sm:h-14 lg:h-16"
                  dir="ltr"
                />
                <div className="flex items-center justify-center bg-gray-50 border-l-2 border-gray-200 w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16">
                  <Search className="w-5 h-5 sm:w-6 sm:h-6 text-gray-400" />
                </div>
              </>
            )}
          </div>
        </form>

        {/* Search Suggestions */}
        <div className="space-y-4 sm:space-y-6">
          <h2 className="text-base sm:text-lg lg:text-xl font-semibold text-gray-800">
            {language === "ar" ? "اقتراحات البحث" : "Search Suggestions"}
          </h2>
          <div className="grid gap-3 sm:gap-4">
            {[
              language === "ar" ? "التقنية" : "Technology",
              language === "ar" ? "الألعاب" : "Games",
              language === "ar" ? "البرمجة" : "Programming",
              language === "ar" ? "الذكي الاصطناعي" : "Artificial Intelligence",
              language === "ar" ? "تطوير المواقع" : "Web Development",
            ].map((suggestion, index) => (
              <button
                key={index}
                onClick={() => setSearchQuery(suggestion)}
                className="flex items-center gap-3 sm:gap-4 p-3 sm:p-4 lg:p-5 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                dir={language === "ar" ? "rtl" : "ltr"}
              >
                <Search className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400 flex-shrink-0" />
                <span className="text-gray-700 text-sm sm:text-base lg:text-lg">{suggestion}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Searches */}
        {searchQuery === "" && (
          <div className="mt-8 sm:mt-12 space-y-4 sm:space-y-6">
            <h2 className="text-base sm:text-lg lg:text-xl font-semibold text-gray-800">
              {language === "ar" ? "عمليات البحث الأخيرة" : "Recent Searches"}
            </h2>
            <div className="text-center py-8 sm:py-12 text-gray-500 text-sm sm:text-base lg:text-lg">
              {language === "ar" ? "لا توجد عمليات بحث سابقة" : "No recent searches"}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
