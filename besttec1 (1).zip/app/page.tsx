"use client"
import { useLanguage } from "@/contexts/LanguageContext"

export default function HomePage() {
  const { language } = useLanguage()

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-10 justify-items-center">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-6 sm:p-8 lg:p-10 w-full max-w-lg lg:max-w-xl xl:max-w-2xl h-64 sm:h-80 lg:h-96 border border-gray-200 hover:shadow-lg transition-all duration-300 cursor-pointer group"
          >
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 bg-gray-300 rounded-full mx-auto mb-4 sm:mb-6 group-hover:bg-gray-400 transition-colors"></div>
                <h3 className="text-lg sm:text-xl lg:text-2xl font-semibold text-gray-800 mb-2 sm:mb-3">
                  {language === "ar" ? `القسم ${i + 1}` : `Section ${i + 1}`}
                </h3>
                <p className="text-gray-600 text-sm sm:text-base lg:text-lg">
                  {language === "ar" ? "محتوى تقني وترفيهي" : "Technical & Entertainment Content"}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
