'use client';
import { useState } from 'react';

export default function Home() {
  const [videoUrl, setVideoUrl] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [message, setMessage] = useState('');

  const handleDownload = async () => {
    const res = await fetch('/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: videoUrl })
    });
    const data = await res.json();
    setMessage(data.message || data.error);
  };

  const handleUpload = async () => {
    if (!uploadFile) return;
    const formData = new FormData();
    formData.append('file', uploadFile);

    const res = await fetch('/api/upload', {
      method: 'POST',
      body: formData
    });

    const data = await res.json();
    setMessage(data.message || data.error);
  };

  return (
    <main className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Social Media Downloader & Uploader</h1>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Paste video URL..."
          value={videoUrl}
          onChange={(e) => setVideoUrl(e.target.value)}
          className="border p-2 w-full"
        />
        <button onClick={handleDownload} className="mt-2 bg-blue-500 text-white px-4 py-2 rounded">
          Download Video
        </button>
      </div>

      <div className="mb-4">
        <input
          type="file"
          onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
          className="block"
        />
        <button onClick={handleUpload} className="mt-2 bg-green-500 text-white px-4 py-2 rounded">
          Upload File
        </button>
      </div>

      {message && <p className="mt-4 text-sm text-gray-600">{message}</p>}
    </main>
  );
}