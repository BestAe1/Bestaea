import { exec } from 'child_process';
import { writeFile } from 'fs';
import { join } from 'path';

export async function POST(req) {
  const { url } = await req.json();
  const outputPath = join(process.cwd(), 'public/uploads');

  return new Promise((resolve) => {
    exec(`yt-dlp -o '${outputPath}/%(title)s.%(ext)s' -f best ${url}`, (err, stdout, stderr) => {
      if (err) {
        resolve(Response.json({ error: stderr }, { status: 500 }));
      } else {
        resolve(Response.json({ message: 'Download complete.' }));
      }
    });
  });
}